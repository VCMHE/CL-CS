import pickle

with open('../Data/Data_pkl/sub_001.pkl', 'rb') as f:
    data = pickle.load(f)
print(1)
